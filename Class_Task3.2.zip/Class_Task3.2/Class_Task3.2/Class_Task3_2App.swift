//
//  Class_Task3_2App.swift
//  Class_Task3.2
//
//  Created by Taibah Valley Academy on 3/6/25.
//

import SwiftUI

@main
struct Class_Task3_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
