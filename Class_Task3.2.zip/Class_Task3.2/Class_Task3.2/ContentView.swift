//
//  ContentView.swift
//  Class_Task3.2
//
//  Created by Taibah Valley Academy on 3/6/25.
//

import SwiftUI

// ViewModel class that conforms to ObservableObject for state management
class UserProfileModel: ObservableObject {
    @Published private var name: String = "Tahani Ayman"
    
    // Getter method to retrieve the name
    func getName() -> String {
        return name
    }
    
    // Setter method to update the name
    func setName(newName: String) {
        name = newName
    }
}

// SwiftUI view to toggle between light and dark modes
struct ColorToggle: View {
    @Binding var isDarkMode: Bool  // Binding property to control dark mode state
    
    var body: some View {
        Toggle("Dark Mode", isOn: $isDarkMode)  // Toggle switch for dark mode
            .padding()
            .foregroundColor(.green)
    }
}

// Main content view
struct ContentView: View {
    @StateObject private var viewModel = UserProfileModel()  // Creates an instance of UserProfileModel
    @State private var name: String = ""  // State variable to store user input
    @State private var isDarkMode: Bool = false  // State variable to track dark mode state
    
    var body: some View {
        ZStack {
            isDarkMode ? Color.black.ignoresSafeArea() : Color.white.ignoresSafeArea()
            // Changes background color based on dark mode state
            
            VStack {
                Text("Name: \(viewModel.getName())")  // Displays the current name
                    .padding()
                    .font(.largeTitle)
                    .foregroundColor(isDarkMode ? .white : .black)  // Adjusts text color based on dark mode
                
                HStack {
                    TextField("Enter your name", text: $name)  // Input field for user to enter their name
                        .padding()
                        .background(isDarkMode ? .white.opacity(0.5) : .gray.opacity(0.5))
                        // Sets background color with opacity based on dark mode
                        .cornerRadius(10)
                    
                    Button("Change") {  // Button to update the name
                        if !name.isEmpty {  // Ensures name is not empty before updating
                            viewModel.setName(newName: name)  // Calls setName method to update name
                        }
                    }
                    .padding()
                    .background(.green)
                    .foregroundColor(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                }
                
                ColorToggle(isDarkMode: $isDarkMode)  // Embeds the dark mode toggle switch
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
